var ground 
var trex ,trex_running;
function preload(){
 trex_running = loadAnimation("trex1.png", "trex3.png", "trex4.png") 
 ground = loadImage("ground2") 


}



function setup(){
  createCanvas(600,300)
  
  trex = createSprite(50, 200, 20, 50);
  trex.addAnimation('run', trex_running)
  ground = createSprite(500, 250, 200, 10)
  ground.addImage(ground)
}

function draw(){
  background("white")
  
  if(keyDown("space"))
  {
    trex.velocityY = -10
  }


  trex.velocityY = trex.velocityY + 0.8

  trex.collide(ground)

  drawSprites()
}
